import org.jasypt.util.text.AES256TextEncryptor;

public class client {

    public void EncryptPassword(String password)
    {
        AES256TextEncryptor aesEncryptor = new AES256TextEncryptor();
        aesEncryptor.setPassword(password);
        String myEncryptedPassword = aesEncryptor.encrypt(password);
        System.out.println(myEncryptedPassword );
    }
    public String DecryptPassword(String passwordFromConfigFile)
    {
        AES256TextEncryptor aesEncryptor = new AES256TextEncryptor();
        aesEncryptor.setPassword("123");
        String decryptedPassword = aesEncryptor.decrypt(passwordFromConfigFile);
        return decryptedPassword;
    }
}
