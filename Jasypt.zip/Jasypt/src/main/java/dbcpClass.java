
import java.sql.*;
import java.util.ResourceBundle;
import java.util.Scanner;

import org.apache.commons.dbcp2.BasicDataSource;


public class dbcpClass
{
    private static BasicDataSource dataSource;

    private static BasicDataSource getDataSource()
    {

        if (dataSource == null)
        {
            String DB_ULR,DataBase,user,password,decryptPassword,pCon ;
            client client = new client();


            ResourceBundle bundle = ResourceBundle.getBundle("DB");
            user=bundle.getString("user");
            password=bundle.getString("password");
            decryptPassword = client.DecryptPassword(password);

            DB_ULR = bundle.getString("DB_ULR");
            DataBase =bundle.getString("databaseName");
            pCon = bundle.getString("pCon");

            BasicDataSource ds = new BasicDataSource();

            ds.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            ds.setUrl(DB_ULR + ";databaseName="+DataBase + pCon);
            ds.setUsername(user);
            ds.setPassword(decryptPassword);


            ds.setMinIdle(5);
            ds.setMaxIdle(10);
            ds.setMaxOpenPreparedStatements(100);


            dataSource = ds;
        }
        return dataSource;
    }

    public static void main(String[] args) throws SQLException
    {

        Scanner myObj = new Scanner(System.in);
        System.out.println("Enter username");

        String userName = myObj.nextLine();

        dbcpClass dbcpClass = new dbcpClass();

        try (BasicDataSource dataSource = dbcpClass.getDataSource();
             Connection connection = dataSource.getConnection();)
        {
            dbcpClass.statementExample( connection);
            dbcpClass.PreparedStatementExample( connection, userName);
            dbcpClass.statementExample( connection);
        }

    }

    public void statementExample( Connection connectionUrl)
    {

        ResultSet resultSet = null;
        try (
             Statement statement = connectionUrl.createStatement();) {

            String selectSql = "SELECT * FROM test";
            resultSet = statement.executeQuery(selectSql);

            while (resultSet.next()) {
                System.out.println("نام : " + resultSet.getString("name") + "****************");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }


    public void PreparedStatementExample( Connection connectionUrl , String userName) {

        try {
            int id = 2;
            PreparedStatement preparedStatement = connectionUrl.prepareStatement("UPDATE [dbo].[test] SET [name] = ? where id = ?");

            preparedStatement.setString(1, userName);
            preparedStatement.setInt(2, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }




}